﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;
using DamasWsTester.Services;

namespace DamasWsTester
{
    public partial class Form1 : Form
    {
        //Certificate abstraction
        private readonly Certificates _certificates;

        //A dictionary of services specified in the PrepareUi method.
        private readonly Dictionary<string, string> _services;

        //Specified services
        private readonly RnpTrainService _rnpTrainService;

        public Form1()
        {
            InitializeComponent();
            Icon = Properties.Resources.Damas_D_transparent;
            

            _certificates = new Certificates(StoreLocation.CurrentUser, X509FindType.FindByKeyUsage);
            _services = new Dictionary<string, string>();
            _rnpTrainService = new RnpTrainService(_certificates);

            //ignoring CA validation (true)
            DisableCaVerification(Program.DisableCertificateValidation);

            PrepareUi();
        }


        private static string GetReadableFormattedString(string environment, string cert, string protocol, string service)
        {
            return $"{string.Format("{0,22}", environment)}   - " +
                   $"{string.Format("{0,15}", service)}   - " +
                   $"{string.Format("{0,20}", cert)}   - " +
                   $"{string.Format("{0,6}", protocol)}";
        }
        
        /// <summary>
        /// Unified method preparing data for UI
        /// </summary>
        private void PrepareUi()
        {
            _services.Add(
                GetReadableFormattedString("rnp-train.unicorn.com", Program.NoCertificate, "HTTP", "DamasService3"), 
                "DamasService_Endpoint_Http2");
            _services.Add(
                GetReadableFormattedString("rnp-train.unicorn.com", Program.NoCertificate, "HTTPS", "DamasService3"), 
                "DamasService_Endpoint_Https2");
            _services.Add(
                GetReadableFormattedString("rnp-train.unicorn.com", "client certificate", "HTTPS", "DamasService2"), 
                "DamasService_Endpoint_Https2C");

            foreach (var item in _services)
            {
                CbServiceName.Items.Add(item.Key);
            }

            CbServiceName.SelectedIndex = 0;

            CbLoginCert.Items.Add(Program.NoCertificate);

            foreach (var cert in _certificates.Collection)
            {
                CbLoginCert.Items.Add(_certificates.GetFriendlyName(cert));
            }

            if (CbLoginCert.Items.Count > 0)
            {
                CbLoginCert.SelectedIndex = 0;
            }
        }

        private void BtGetDate_Click(object sender, EventArgs e)
        {
            foreach (var item in _services.Where(item => CbServiceName.Text == item.Key))
            {
                _rnpTrainService.GetData(item.Value, CbLoginCert.Text, TbUsername.Text, TbPassword.Text);
            }
        }

        /// <summary>
        /// Call this with true to disable CA validation, can be used when testing with self-sign CA
        /// </summary>
        /// <param name="disable">if set to true, CA will not be validated</param>
        private void DisableCaVerification(bool disable)
        {
            if (disable)
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) => true;
            }
        }

        private void TSIAbout_Click(object sender, EventArgs e) => new About().Show();

        private void CbServiceName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CbServiceName.Text.Contains(Program.NoCertificate))
            {
                if (CbLoginCert.Items.Count > 0)
                {
                    CbLoginCert.SelectedIndex = 0;
                }
                CbLoginCert.Enabled = false;
            }
            else
            {
                CbLoginCert.Enabled = true;
            }    
        }
    }
}
