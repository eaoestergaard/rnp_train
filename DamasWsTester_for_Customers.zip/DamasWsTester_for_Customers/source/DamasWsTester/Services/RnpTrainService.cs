﻿using System;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel.Security.Tokens;
using System.Windows.Forms;
using DamasWsTester.RnpTrainDS;

namespace DamasWsTester.Services
{
    class RnpTrainService
    {
        /// <summary>
        /// Default constructor for passing certificates class
        /// </summary>
        private readonly Certificates _certificates;
        public RnpTrainService(Certificates certificates)
        {
            _certificates = certificates;
        }

        /// <summary>
        /// GetData method returning DateTime from server by calling GetActualDateTime.
        /// </summary>
        /// <param name="serviceEndpoint"></param>
        /// <param name="certificateName"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        public void GetData(string serviceEndpoint, string certificateName, string userName, string password)
        {
            var client = new RnpDamasServiceClient(serviceEndpoint);;

            if (certificateName != Program.NoCertificate)
            {
                //configure service for certificates - only for client certificates 
                var serverCertificate = _certificates.GetCertByName("rnp-train.unicorn.com");
                if (serverCertificate == null)
                {
                    MessageBox.Show("The public certificate: rnp-train.unicorn.com was not found in the certificate store." +
                                    "Please import the public SSL certificate rnp-train.unicorn.com into your store.");
                    
                    return;
                }
                
                ModifyBinding((CustomBinding)client.Endpoint.Binding);
                client.ClientCredentials.ClientCertificate.Certificate = _certificates.GetCertByName(certificateName);
                client.ClientCredentials.ServiceCertificate.DefaultCertificate = serverCertificate;
            }
            

            //Defining user name and password for login
            client.ClientCredentials.UserName.UserName = userName;
            client.ClientCredentials.UserName.Password = Utils.Md5Hash(password);

            try
            {
                var result = client.GetActualDateTime();
                client.Close();
                MessageBox.Show(result.Result.InnerText, @"Date from " + serviceEndpoint);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, e.Source);
                if (e.InnerException != null)
                {
                    MessageBox.Show(e.InnerException.Message, e.InnerException.Source);
                }
            }
        }
        private void ModifyBinding(CustomBinding binding)
        {
            var asymmetricBindingElement = (AsymmetricSecurityBindingElement)binding.Elements.First();
            asymmetricBindingElement.EndpointSupportingTokenParameters.Signed.Add(new UserNameSecurityTokenParameters());
        }
    }
}
