﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace DamasWsTester
{
    internal class Utils
    {
        /// <summary>
        /// Return Base64 formatted hash of input string
        /// </summary>
        /// <param name="password">Password passed from user input</param>
        /// <returns></returns>
        internal static string Md5Hash(string password) =>
            Convert.ToBase64String(MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(password)));
    }
}