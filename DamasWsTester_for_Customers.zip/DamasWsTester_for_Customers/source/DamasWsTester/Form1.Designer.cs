﻿namespace DamasWsTester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CbServiceName = new System.Windows.Forms.ComboBox();
            this.TbUsername = new System.Windows.Forms.TextBox();
            this.TbPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CbLoginCert = new System.Windows.Forms.ComboBox();
            this.BtGetDate = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.TSIAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CbServiceName
            // 
            this.CbServiceName.FormattingEnabled = true;
            this.CbServiceName.Location = new System.Drawing.Point(40, 46);
            this.CbServiceName.Margin = new System.Windows.Forms.Padding(2);
            this.CbServiceName.Name = "CbServiceName";
            this.CbServiceName.Size = new System.Drawing.Size(507, 23);
            this.CbServiceName.TabIndex = 0;
            this.CbServiceName.SelectedIndexChanged += new System.EventHandler(this.CbServiceName_SelectedIndexChanged);
            // 
            // TbUsername
            // 
            this.TbUsername.Location = new System.Drawing.Point(128, 87);
            this.TbUsername.Margin = new System.Windows.Forms.Padding(2);
            this.TbUsername.Name = "TbUsername";
            this.TbUsername.Size = new System.Drawing.Size(373, 23);
            this.TbUsername.TabIndex = 1;
            // 
            // TbPassword
            // 
            this.TbPassword.Location = new System.Drawing.Point(128, 125);
            this.TbPassword.Margin = new System.Windows.Forms.Padding(2);
            this.TbPassword.Multiline = true;
            this.TbPassword.Name = "TbPassword";
            this.TbPassword.PasswordChar = '*';
            this.TbPassword.Size = new System.Drawing.Size(373, 22);
            this.TbPassword.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 128);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 163);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Login cert";
            // 
            // CbLoginCert
            // 
            this.CbLoginCert.FormattingEnabled = true;
            this.CbLoginCert.Location = new System.Drawing.Point(128, 160);
            this.CbLoginCert.Margin = new System.Windows.Forms.Padding(2);
            this.CbLoginCert.Name = "CbLoginCert";
            this.CbLoginCert.Size = new System.Drawing.Size(373, 23);
            this.CbLoginCert.TabIndex = 8;
            // 
            // BtGetDate
            // 
            this.BtGetDate.Location = new System.Drawing.Point(183, 210);
            this.BtGetDate.Margin = new System.Windows.Forms.Padding(2);
            this.BtGetDate.Name = "BtGetDate";
            this.BtGetDate.Size = new System.Drawing.Size(230, 35);
            this.BtGetDate.TabIndex = 9;
            this.BtGetDate.Text = "Get Date and Time";
            this.BtGetDate.UseVisualStyleBackColor = true;
            this.BtGetDate.Click += new System.EventHandler(this.BtGetDate_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {this.TSIAbout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(589, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // TSIAbout
            // 
            this.TSIAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TSIAbout.Name = "TSIAbout";
            this.TSIAbout.Size = new System.Drawing.Size(52, 20);
            this.TSIAbout.Text = "About";
            this.TSIAbout.Click += new System.EventHandler(this.TSIAbout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 264);
            this.Controls.Add(this.BtGetDate);
            this.Controls.Add(this.CbLoginCert);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TbPassword);
            this.Controls.Add(this.TbUsername);
            this.Controls.Add(this.CbServiceName);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "DAMAS WS TESTER";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox CbServiceName;
        private System.Windows.Forms.TextBox TbUsername;
        private System.Windows.Forms.TextBox TbPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox CbLoginCert;
        private System.Windows.Forms.Button BtGetDate;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TSIAbout;
    }
}

