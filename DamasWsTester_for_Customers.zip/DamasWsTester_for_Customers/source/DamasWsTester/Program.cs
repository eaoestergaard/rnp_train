﻿using System;
using System.Windows.Forms;

namespace DamasWsTester
{

    static class Program
    {
        public const string NoCertificate = "No certificate";
        public const bool DisableCertificateValidation = false;
        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
